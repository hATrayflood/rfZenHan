from distutils.core import setup;
setup(
	name="rfZenHan",
	version="0.4",
	py_modules=["rfZenHan"],
	scripts=['rfzenhan', 'rfzenhan.bat', 'rfZenHanCmd.py'],
)
